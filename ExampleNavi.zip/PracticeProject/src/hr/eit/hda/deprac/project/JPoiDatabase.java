package hr.eit.hda.deprac.project;
import java.util.*;
public class JPoiDatabase {
	private Map<String,JPoi> m_poiMap = new HashMap<>();
	
	public void addPoi(JPoi poi) {
		if(poi != null) {
			if(!m_poiMap.containsKey(poi.getName())) {
				m_poiMap.put(poi.getName(), poi);
			}
			else {
				System.out.println("The map already has the key therefore can't allow to insert again");
			}
		}
		else {
			System.out.println("Object passed is null");
		}
	}
	
	public JPoi getPoi(String name) {
		if(m_poiMap.containsKey(name)) {
			return m_poiMap.get(name);
		}
		else {
			System.out.println("The key doesn't belong to our map");
			return null;
		}
	}
	
	public boolean deletePoi(String name) {
		if(m_poiMap.containsKey(name)) {
			m_poiMap.remove(name);
			return true;
		}
		System.out.println("Deletion not succeded since element not present");
		return false;
	}
	
	public Map<String,JPoi> getPoiMap(){
		return m_poiMap;
	}
	
	public void print() {
		for(Map.Entry<String,JPoi> entry : m_poiMap.entrySet()) {
			String key = entry.getKey();
			JPoi value = entry.getValue();
			System.out.println("Key = "+key+", value = ");
			value.print();
		}
	}
	
}
