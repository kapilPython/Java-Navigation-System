package hr.eit.hda.deprac.project;
public class JCaller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JWaypoint wp = new JWaypoint("Random",53.5,121.25);
		JPoi poi = new JPoi(T_poi.UNIVERSITY,"H_DA","Best Practical University in Germany"
				,53.2,122.35);
		//wp.print(wp.DEGREE);
		//wp.print(wp.MMSS);
		//poi.print();
		/**
		 * Application of Copy Constructor for JWaypoint
		 */
		//JWaypoint wp1 = new JWaypoint(wp);
		//wp1.print(wp1.DEGREE);
		JPoiDatabase poiDb = new JPoiDatabase();
		poiDb.addPoi(poi);
		//poiDb.print();
		JWpDatabase wpDb = new JWpDatabase();
		wpDb.addWp(wp);
		//wpDb.print();
		JRoute rt = new JRoute();
		rt.connectToWpDatabase(wpDb);
		rt.connectToPoiDatabase(poiDb);
		rt.addWaypoint("Random");
		rt.addPoi("H_DA");
		rt.print();
		
		/**
		 * Application for JRoute copy constructor 
		 */
		
		//JRoute rt1 = new JRoute(rt);
		//rt1.print();
		JCsvParser csv = new JCsvParser();
		//csv.setMediaName("wp.txt");
		csv.writeData(wpDb, poiDb);
	}

}
