package hr.eit.hda.deprac.project;

public class JPoi extends JWaypoint {
	private String m_description;
	private T_poi m_type;
	public JPoi(T_poi type,String name,String description,double latitude,double longitude) {
		// TODO Auto-generated constructor stub
		super(name,latitude,longitude);
		m_description = description;
		m_type = type;
	}
	public void print() {
		System.out.println("================Poi of type " + m_type);
		super.print(DEGREE);
		System.out.println(m_description);
	}

	public void getAllDataByReference(JPoi poi) {
		poi.getAllDataByReference(poi);
		poi.m_description = m_description;
		poi.m_type = m_type;
	}
	
	public String toString() {
		return m_type+","+m_name + ","+m_description+","+m_latitude+","+m_longitude;
	}
	
}
