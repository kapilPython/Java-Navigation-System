package hr.eit.hda.deprac.project;
import java.util.*;
public class JRoute {
	private ArrayList<JWaypoint> m_route = new ArrayList<>();
	private JWpDatabase m_wpDb;
	private JPoiDatabase m_poiDb;
	public JRoute(){
		m_wpDb = null;
		m_poiDb = null;
	}
	
	JRoute(JRoute rt){
		this.m_route = rt.m_route;
		this.m_wpDb = rt.m_wpDb;
		this.m_poiDb = rt.m_poiDb;
		//rt.m_route.addAll(this.m_route);
	}
	
	public void connectToWpDatabase(JWpDatabase wpDb) {
		m_wpDb = wpDb;
	}
	
	public void connectToPoiDatabase(JPoiDatabase poiDb) {
		m_poiDb = poiDb;
	}
	
	public void addWaypoint(String name) {
		if(m_wpDb != null) {
			m_route.add(m_wpDb.getWp(name));
		}
		else {
			System.out.println("Wp Database is not connected");
		}
	}
	
	public void addPoi(String name) {
		if(m_poiDb != null) {
			m_route.add(m_poiDb.getPoi(name));
		}
		else {
			System.out.println("Poi Database is not connected");
		}
	}
	
	public void print() {
		for(JWaypoint wp : m_route) {
			/**
			 * instanceof used for dynamic casting the JPoi object from JWaypoint
			 * the derived class
			 */
			if(wp instanceof JPoi) {
				//System.out.println("I'm a poi object");
				((JPoi)wp).print();
			}
			else {
				wp.print(wp.DEGREE);
			}
		}
	}
	
}
