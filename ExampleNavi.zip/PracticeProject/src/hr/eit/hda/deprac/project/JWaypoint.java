package hr.eit.hda.deprac.project;
import java.util.*;

public class JWaypoint {
	protected String m_name;
	protected double m_latitude;
	protected double m_longitude;
	private final double pi = 3.14; 
	public final int DEGREE = 1;
	public final int MMSS = 2;
	public JWaypoint(String name,double latitude,double longitude) {
		// TODO Auto-generated constructor stub
		m_name = name;
		m_latitude = latitude;
		m_longitude = longitude;
	}
	
	public JWaypoint() {
		m_name = "Random";
		m_latitude = 0;
		m_longitude = 0;
	}
	
	JWaypoint(JWaypoint wp){
		this.m_name = wp.m_name;
		this.m_latitude = wp.m_latitude;
		this.m_longitude = wp.m_longitude;
	}
	
	public void set(String name,double latitude,double longitude) {
		m_name = name;
		m_latitude = latitude;
		m_longitude = longitude;
	}

	public String getName() {
		return m_name;
	}
	
	public double getLatitude() {
		return m_latitude;
	}
	
	public double getLongitude() {
		return m_longitude;
	}
	/**
	 * Example for call by reference
	 * The call by reference in java is specifically used by referencing an object
	 * @param wp
	 */
	public void getAllDataByReference(JWaypoint wp) {
		wp.m_name = m_name;
		wp.m_latitude = m_latitude;
		wp.m_longitude = m_longitude;
	}
	
	public double calculateDistance(final JWaypoint wp) {
		double lati1 = (m_latitude)*(pi/180);
		double lati2 = (wp.m_latitude)*(pi/180);
		double longi1 = (m_longitude)*(pi/180);
		double longi2 = (wp.m_longitude)*(pi/180);
		double value1 = (Math.sin(lati1))*(Math.sin(lati2));
		double value2 = (Math.cos(lati1))*(Math.cos(lati2))*(Math.cos(longi2 - longi1));
		double dist = 6378.18 * Math.acos(value1 + value2);
		return dist;
	}
	
	public void print(int format) {
		JWpDegMmSs dms = new JWpDegMmSs();
		switch(format) {
		case DEGREE:
			System.out.println(getName() + " on "+"Latitude = " 
		+ getLatitude() + " and Longitude = " + getLongitude());
			break;
		case MMSS:
			dms.transformLatitude2degmmss();
			System.out.print(getName() + " on "+"Latitude = " + dms.getDeg() 
			+ "deg " + dms.getMM() + "MM " + dms.getSS() + "SS");
			dms.transformLongitude2degmmss();
			System.out.println("Longitude = " + dms.getDeg() 
			+ "deg " + dms.getMM() + "MM " + dms.getSS() + "SS");
			break;
			default:
				break;
		}
	}
	
	public String toString() {
		return m_name + ","+m_latitude+","+m_longitude;
	}
	
	class JWpDegMmSs{
		private double m_deg;
		private double  m_mm;
		private double m_ss;
		JWpDegMmSs(){
			m_deg = 0;
			m_mm = 0;
			m_ss = 0;
		}
		
		public void transformLongitude2degmmss() {
			transform2degmmss(m_longitude);
		}
		
		public void transformLatitude2degmmss() {
			transform2degmmss(m_latitude);
		}
		
		public void transform2degmmss(double value) {
			double fractPart;
			double fractPart1;
			m_deg = Math.floor(value);
			try {
				fractPart = value % m_deg;
			}
			catch(Exception e) {
				fractPart = 0;
			}
			m_mm = Math.floor(fractPart*60);
			try {
				fractPart1 = (fractPart*60) % m_mm;
			}
			catch(Exception e) {
				fractPart1 = 0;
			}
			m_ss = fractPart1*60;
		}
		public double getDeg() {
			return m_deg;
		}
		public double getMM() {
			return m_mm;
		}
		public double getSS() {
			return m_ss;
		}
	}
}
