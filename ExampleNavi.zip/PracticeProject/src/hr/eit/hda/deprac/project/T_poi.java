package hr.eit.hda.deprac.project;

public enum T_poi {
	RESTAURANT,
	TOURISTIC,
	GASSTATION,
	UNIVERSITY;
}
	
