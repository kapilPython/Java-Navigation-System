package hr.eit.hda.deprac.project;

public interface JPersistantStorage {
	public void setMediaName(String name);
	public boolean writeData(final JWpDatabase wpDb,final JPoiDatabase poiDb);
}
