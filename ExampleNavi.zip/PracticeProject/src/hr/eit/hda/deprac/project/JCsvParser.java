package hr.eit.hda.deprac.project;
import java.io.*;
import java.util.*;
public class JCsvParser implements JPersistantStorage {
	private String m_mediaName;
	private Map<String,JWaypoint> m_wpDb = new HashMap<>();
	private Map<String,JPoi> m_poiDb = new HashMap<>();
	public void setMediaName(String name){
		m_mediaName = name;
	}
	
	public boolean writeData(final JWpDatabase wpDb,final JPoiDatabase poiDb) {
		m_wpDb = wpDb.getWpMap();
		m_poiDb = poiDb.getPoiMap();
		try{    
			FileWriter fw=new FileWriter("C:\\Users\\swapnil\\eclipse-java-workspace\\PracticeProject\\WriteDirectory\\wp.txt");
			for(Map.Entry<String, JWaypoint> entry: m_wpDb.entrySet()) {
				fw.write((entry.getValue()).getName() + ","+
			(entry.getValue()).getLatitude()+","+(entry.getValue()).getLongitude());
			}   
			fw.close();    
		}
		catch(Exception e){
			System.out.println(e);
		}
		try{    
			FileWriter fw=new FileWriter("C:\\Users\\swapnil\\eclipse-java-workspace\\PracticeProject\\WriteDirectory\\poi.txt");
			for(Map.Entry<String, JPoi> entry: m_poiDb.entrySet()) {
				fw.write((entry.getValue()).getName() + ","+
			(entry.getValue()).getLatitude()+","+(entry.getValue()).getLongitude()); 
			}   
			fw.close();    
		}
		catch(Exception e){
			System.out.println(e);
		}  
		System.out.println("Success...");  
		return true;
	}
	
}
