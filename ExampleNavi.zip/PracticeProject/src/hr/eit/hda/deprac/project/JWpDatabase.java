package hr.eit.hda.deprac.project;
import java.util.*;
public class JWpDatabase {
private Map<String,JWaypoint> m_WpMap = new HashMap<>();
	
	public void addWp(JWaypoint poi) {
		if(poi != null) {
			if(!m_WpMap.containsKey(poi.getName())) {
				m_WpMap.put(poi.getName(), poi);
			}
			else {
				System.out.println("The map already has the key therefore can't allow to insert again");
			}
		}
		else {
			System.out.println("Object passed is null");
		}
	}
	
	public JWaypoint getWp(String name) {
		if(m_WpMap.containsKey(name)) {
			return m_WpMap.get(name);
		}
		else {
			System.out.println("The key doesn't belong to our map");
			return null;
		}
	}
	
	public boolean deleteWp(String name) {
		if(m_WpMap.containsKey(name)) {
			m_WpMap.remove(name);
			return true;
		}
		System.out.println("Deletion not succeded since element not present");
		return false;
	}
	
	public Map<String,JWaypoint> getWpMap(){
		return m_WpMap;
	}
	
	public void print() {
		for(Map.Entry<String,JWaypoint> entry : m_WpMap.entrySet()) {
			String key = entry.getKey();
			JWaypoint value = entry.getValue();
			System.out.println("Key = "+key+", value = ");
			value.print(value.DEGREE);
		}
	}
}
